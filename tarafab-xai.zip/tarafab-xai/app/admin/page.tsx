'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

interface ClientAccount {
  id: string
  user_id: string
  account_balance: number
  available_balance: number
  invested_balance: number
  pending_balance: number
  profile: {
    full_name: string
    email: string
  }
}

export default function AdminPage() {
  const [user, setUser] = useState<any>(null)
  const [clients, setClients] = useState<ClientAccount[]>([])
  const [loading, setLoading] = useState(true)
  const [signOutLoading, setSignOutLoading] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editValue, setEditValue] = useState<string>('')
  const [savingId, setSavingId] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const loadAdmin = async () => {
      try {
        // Get session
        const { data: { session }, error: sessionError } = await supabase.auth.getSession()
        
        if (sessionError || !session) {
          router.push('/sign-in')
          return
        }

        // Check if user is admin
        const { data: profile } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', session.user.id)
          .single()

        if (!profile || profile.role !== 'admin') {
          router.push('/dashboard')
          return
        }

        setUser(session.user)

        // Get all client accounts with their profiles
        const { data: accounts } = await supabase
          .from('accounts')
          .select(`
            id,
            user_id,
            account_balance,
            available_balance,
            invested_balance,
            pending_balance
          `)

        if (accounts) {
          // Fetch profiles for each account
          const clientsWithProfiles = await Promise.all(
            accounts.map(async (account) => {
              const { data: profileData } = await supabase
                .from('profiles')
                .select('full_name, email')
                .eq('id', account.user_id)
                .single()

              return {
                ...account,
                profile: profileData || { full_name: 'Unknown', email: 'N/A' },
              }
            })
          )

          setClients(clientsWithProfiles)
        }
      } catch (err) {
        console.error('Error loading admin:', err)
      } finally {
        setLoading(false)
      }
    }

    loadAdmin()
  }, [router, supabase])

  const handleSignOut = async () => {
    setSignOutLoading(true)
    await supabase.auth.signOut()
    router.push('/')
  }

  const handleEditProfitBalance = (accountId: string, currentValue: number) => {
    setEditingId(accountId)
    setEditValue(currentValue.toString())
  }

  const handleSaveProfitBalance = async (accountId: string) => {
    setSavingId(accountId)
    try {
      const newValue = parseFloat(editValue)
      if (isNaN(newValue) || newValue < 0) {
        alert('Please enter a valid positive number')
        return
      }

      await supabase
        .from('accounts')
        .update({ available_balance: newValue })
        .eq('id', accountId)

      // Update local state
      setClients(clients.map(c => 
        c.id === accountId 
          ? { ...c, available_balance: newValue }
          : c
      ))

      setEditingId(null)
      setEditValue('')
    } catch (err) {
      alert('Failed to update profit balance')
    } finally {
      setSavingId(null)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-950 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
          <p className="mt-4 text-gray-400">Loading admin panel...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 to-gray-900">
      {/* Header */}
      <header className="border-b border-white/5 bg-gray-900/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-serif font-bold text-white">
                Admin Panel
              </h1>
              <p className="text-sm text-gray-400">Manage client accounts</p>
            </div>
            <button
              onClick={handleSignOut}
              disabled={signOutLoading}
              className="px-4 py-2 text-sm font-medium text-white border border-white/20 rounded-lg hover:bg-white/5 transition-all disabled:opacity-50"
            >
              {signOutLoading ? 'Signing Out...' : 'Sign Out'}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="card">
          <h2 className="text-lg font-serif font-bold mb-6">Client Accounts</h2>

          {clients.length === 0 ? (
            <p className="text-center text-gray-500 py-8">No client accounts found</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/5">
                    <th className="text-left text-xs font-semibold text-gray-400 pb-3">Name</th>
                    <th className="text-left text-xs font-semibold text-gray-400 pb-3">Email</th>
                    <th className="text-right text-xs font-semibold text-gray-400 pb-3">
                      Account Balance
                    </th>
                    <th className="text-right text-xs font-semibold text-gray-400 pb-3">
                      Profit Balance
                    </th>
                    <th className="text-center text-xs font-semibold text-gray-400 pb-3">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {clients.map((client) => (
                    <tr key={client.id} className="border-b border-white/5 last:border-b-0">
                      <td className="py-4 text-sm font-medium text-white">
                        {client.profile.full_name}
                      </td>
                      <td className="py-4 text-sm text-gray-400">
                        {client.profile.email}
                      </td>
                      <td className="py-4 text-sm font-mono text-emerald-400 text-right">
                        ${client.account_balance.toFixed(2)}
                      </td>
                      <td className="py-4 text-sm font-mono text-amber-300 text-right">
                        {editingId === client.id ? (
                          <input
                            type="number"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            className="w-32 px-2 py-1 bg-gray-800 border border-emerald-500 rounded text-white font-mono text-right"
                            placeholder="0.00"
                            step="0.01"
                            min="0"
                          />
                        ) : (
                          `$${client.available_balance.toFixed(2)}`
                        )}
                      </td>
                      <td className="py-4 text-center">
                        {editingId === client.id ? (
                          <div className="flex gap-2 justify-center">
                            <button
                              onClick={() => handleSaveProfitBalance(client.id)}
                              disabled={savingId === client.id}
                              className="px-3 py-1 text-xs font-medium bg-emerald-600 text-white rounded hover:bg-emerald-700 disabled:opacity-50"
                            >
                              {savingId === client.id ? 'Saving...' : 'Save'}
                            </button>
                            <button
                              onClick={() => setEditingId(null)}
                              className="px-3 py-1 text-xs font-medium bg-gray-700 text-white rounded hover:bg-gray-600"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() =>
                              handleEditProfitBalance(
                                client.id,
                                client.available_balance
                              )
                            }
                            className="px-3 py-1 text-xs font-medium bg-amber-600 text-white rounded hover:bg-amber-700"
                          >
                            Edit
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Info Box */}
          <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
            <p className="text-xs text-blue-300">
              <strong>Admin Note:</strong> You can only edit the profit balance field. 
              This represents the available balance that can be invested. All changes are 
              automatically logged.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
