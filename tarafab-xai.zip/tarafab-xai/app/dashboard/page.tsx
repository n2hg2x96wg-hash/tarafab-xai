'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

interface Account {
  id: string
  user_id: string
  account_balance: number
  available_balance: number
  invested_balance: number
  pending_balance: number
}

interface Transaction {
  id: string
  type: string
  amount: number
  status: string
  created_at: string
}

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [account, setAccount] = useState<Account | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [signOutLoading, setSignOutLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const loadDashboard = async () => {
      try {
        // Get session
        const { data: { session }, error: sessionError } = await supabase.auth.getSession()
        
        if (sessionError || !session) {
          router.push('/sign-in')
          return
        }

        setUser(session.user)

        // Get profile
        const { data: profileData } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single()

        if (profileData) {
          // Only customers can see dashboard
          if (profileData.role !== 'customer') {
            if (profileData.role === 'admin') {
              router.push('/admin')
            }
            return
          }
          setProfile(profileData)
        }

        // Get account
        const { data: accountData } = await supabase
          .from('accounts')
          .select('*')
          .eq('user_id', session.user.id)
          .single()

        if (accountData) {
          setAccount(accountData)
        }

        // Get transactions
        const { data: transactionData } = await supabase
          .from('transactions')
          .select('*')
          .eq('user_id', session.user.id)
          .order('created_at', { ascending: false })
          .limit(10)

        if (transactionData) {
          setTransactions(transactionData)
        }
      } catch (err) {
        console.error('Error loading dashboard:', err)
      } finally {
        setLoading(false)
      }
    }

    loadDashboard()
  }, [router, supabase])

  const handleSignOut = async () => {
    setSignOutLoading(true)
    await supabase.auth.signOut()
    router.push('/')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-950 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
          <p className="mt-4 text-gray-400">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 to-gray-900">
      {/* Header */}
      <header className="border-b border-white/5 bg-gray-900/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-serif font-bold text-white">
                {profile?.full_name || 'Dashboard'}
              </h1>
              <p className="text-sm text-gray-400">{user?.email}</p>
            </div>
            <button
              onClick={handleSignOut}
              disabled={signOutLoading}
              className="px-4 py-2 text-sm font-medium text-white border border-white/20 rounded-lg hover:bg-white/5 transition-all disabled:opacity-50"
            >
              {signOutLoading ? 'Signing Out...' : 'Sign Out'}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Account Balance Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {/* Account Balance */}
          <div className="card">
            <p className="text-sm text-gray-400 mb-2">Account Balance</p>
            <p className="text-4xl font-mono font-bold text-white mb-1">
              ${(account?.account_balance || 0).toFixed(2)}
            </p>
            <p className="text-xs text-gray-500">Total value in account</p>
          </div>

          {/* Profit Balance */}
          <div className="card bg-gradient-to-br from-amber-900/20 to-amber-800/10 border-amber-500/20">
            <p className="text-sm text-gray-400 mb-2">Profit Balance</p>
            <p className="text-4xl font-mono font-bold text-amber-300 mb-1">
              ${(account?.available_balance || 0).toFixed(2)}
            </p>
            <p className="text-xs text-gray-500">
              Set by your account manager
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { label: 'Deposit', icon: '↓', color: 'emerald' },
            { label: 'Withdraw', icon: '↑', color: 'red' },
            { label: 'Transfer', icon: '↔', color: 'blue' },
            { label: 'History', icon: '📋', color: 'purple' },
          ].map((action, i) => (
            <button
              key={i}
              className="card group hover:border-white/20 transition-all"
            >
              <div className="text-2xl mb-2">{action.icon}</div>
              <p className="text-sm font-medium text-gray-300 group-hover:text-white">
                {action.label}
              </p>
            </button>
          ))}
        </div>

        {/* Available and Invested Breakdown */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <div className="card">
            <h3 className="text-lg font-serif font-bold mb-4">Available Balance</h3>
            <p className="text-3xl font-mono font-bold text-emerald-400 mb-2">
              ${(account?.available_balance || 0).toFixed(2)}
            </p>
            <p className="text-xs text-gray-500">Ready to invest</p>
          </div>

          <div className="card">
            <h3 className="text-lg font-serif font-bold mb-4">Invested Balance</h3>
            <p className="text-3xl font-mono font-bold text-emerald-400 mb-2">
              ${(account?.invested_balance || 0).toFixed(2)}
            </p>
            <p className="text-xs text-gray-500">Currently deployed</p>
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="card">
          <h3 className="text-lg font-serif font-bold mb-6">Recent Transactions</h3>
          
          {transactions.length === 0 ? (
            <p className="text-center text-gray-500 py-8">No transactions yet</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/5">
                    <th className="text-left text-xs font-semibold text-gray-400 pb-3">Type</th>
                    <th className="text-left text-xs font-semibold text-gray-400 pb-3">Amount</th>
                    <th className="text-left text-xs font-semibold text-gray-400 pb-3">Status</th>
                    <th className="text-left text-xs font-semibold text-gray-400 pb-3">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((tx) => (
                    <tr key={tx.id} className="border-b border-white/5 last:border-b-0">
                      <td className="py-3 text-sm font-mono text-white capitalize">
                        {tx.type.replace('_', ' ')}
                      </td>
                      <td className="py-3 text-sm font-mono text-emerald-400">
                        ${tx.amount.toFixed(2)}
                      </td>
                      <td className="py-3 text-sm">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          tx.status === 'completed'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : tx.status === 'pending'
                            ? 'bg-yellow-500/20 text-yellow-300'
                            : 'bg-red-500/20 text-red-300'
                        }`}>
                          {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                        </span>
                      </td>
                      <td className="py-3 text-sm text-gray-400">
                        {new Date(tx.created_at).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
