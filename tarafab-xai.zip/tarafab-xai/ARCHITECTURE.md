# Tarafab.XAi - Architecture Overview

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Browser / Client                        │
│  (Landing, Auth, Dashboard, Admin Panel)                    │
└──────────────┬──────────────────────────────────────────────┘
               │ HTTPS
               │
┌──────────────▼──────────────────────────────────────────────┐
│                   Vercel (Next.js)                           │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  App Router (TypeScript + React)                      │  │
│  │  ├─ / (Landing)                                       │  │
│  │  ├─ /sign-in                                          │  │
│  │  ├─ /sign-up                                          │  │
│  │  ├─ /dashboard (customer)                            │  │
│  │  ├─ /admin (staff)                                   │  │
│  │  └─ /staff-login (password gate)                    │  │
│  │                                                        │  │
│  │  Styling: Tailwind CSS + Custom CSS                 │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────┬──────────────────────────────────────────────┘
               │ REST API + Auth
               │
┌──────────────▼──────────────────────────────────────────────┐
│              Supabase Backend                                │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  PostgreSQL Database                                  │  │
│  │  ├─ auth.users (Supabase Auth)                       │  │
│  │  ├─ profiles (customer/admin data)                   │  │
│  │  ├─ accounts (balances: account/available/invested)  │  │
│  │  ├─ transactions (deposits/withdrawals/transfers)    │  │
│  │  ├─ transaction_events (audit trail)                 │  │
│  │  └─ audit_logs (admin action logging)                │  │
│  │                                                        │  │
│  │  Features:                                            │  │
│  │  ├─ Row Level Security (RLS) policies                │  │
│  │  ├─ Auth integration (JWT)                           │  │
│  │  └─ Real-time subscriptions (optional)               │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

## Data Flow

### Sign Up Flow
```
User fills form (/sign-up)
  ↓
Supabase Auth creates user + password hash
  ↓
App creates profile (role: customer)
  ↓
App creates account (zero balances)
  ↓
Redirect to /dashboard
```

### Sign In Flow
```
User enters email + password (/sign-in)
  ↓
Supabase Auth validates credentials
  ↓
JWT token returned + stored in cookie
  ↓
Check profile.role
  ├─ role = 'customer' → /dashboard
  └─ role = 'admin' → /admin
```

### Admin Updates Profit Balance
```
Admin views clients (/admin)
  ↓
Admin clicks "Edit" on profit balance
  ↓
Admin enters new amount and clicks "Save"
  ↓
App updates accounts.available_balance
  ↓
Change logged in audit_logs
  ↓
Client sees new balance on next refresh
```

## Component Structure

### Layout Hierarchy
```
layout.tsx (root)
  ├─ page.tsx (Landing)
  ├─ sign-in/
  │   └─ page.tsx
  ├─ sign-up/
  │   └─ page.tsx
  ├─ dashboard/
  │   └─ page.tsx
  ├─ admin/
  │   └─ page.tsx
  └─ staff-login/
      └─ page.tsx
```

All pages are **Client Components** (`'use client'`) because they need:
- Real-time session management
- Supabase client interactions
- User-specific data fetching

## Authentication Layers

### Layer 1: Supabase Auth (Backend)
- Email + password registration
- Password hashing (bcrypt)
- JWT token generation
- Session persistence via HttpOnly cookies
- Real-time session tracking

### Layer 2: Role-Based Access Control
- Profiles table stores role: 'customer' | 'admin'
- Dashboard checks role → redirects appropriately
- Admin panel requires admin role
- Staff login requires password + admin role

### Layer 3: Row Level Security (RLS)
- Database policies enforce data isolation
- Users only see their own account/transactions
- Admins can see all accounts (future policy)
- Ensures backend security even if frontend is bypassed

## Database Schema Details

### auth.users (Supabase managed)
```sql
id UUID PRIMARY KEY
email TEXT UNIQUE
encrypted_password TEXT
created_at TIMESTAMP
updated_at TIMESTAMP
last_sign_in_at TIMESTAMP
```

### profiles
```sql
id UUID PRIMARY KEY (foreign key to auth.users)
full_name TEXT
role TEXT CHECK (role IN ('customer', 'admin'))
email_verified_at TIMESTAMP
account_status TEXT ('active' | 'suspended')
verification_status TEXT ('unverified' | 'pending' | 'verified' | 'rejected')
created_at TIMESTAMP
updated_at TIMESTAMP
```

### accounts
```sql
id UUID PRIMARY KEY
user_id UUID FOREIGN KEY (unique)
account_balance NUMERIC (>= 0)
available_balance NUMERIC (>= 0) -- Profit balance (admin-editable)
invested_balance NUMERIC (>= 0) -- Currently deployed
pending_balance NUMERIC (>= 0) -- Awaiting confirmation
created_at TIMESTAMP
updated_at TIMESTAMP
```

### transactions
```sql
id UUID PRIMARY KEY
user_id UUID FOREIGN KEY
type TEXT IN ('deposit', 'withdrawal', 'transfer_out', 
              'transfer_in', 'investment', 'fee', 'return', 'adjustment')
method TEXT NULLABLE (e.g., 'bank_transfer', 'crypto')
amount NUMERIC (> 0)
fee NUMERIC (>= 0)
asset TEXT DEFAULT 'USD'
address TEXT NULLABLE (crypto address)
network TEXT NULLABLE (e.g., 'bitcoin', 'ethereum')
recipient_id UUID NULLABLE (for transfers)
status TEXT DEFAULT 'pending'
reference TEXT NULLABLE
tx_hash TEXT NULLABLE (blockchain tx hash)
created_at TIMESTAMP
updated_at TIMESTAMP
```

### transaction_events
```sql
id UUID PRIMARY KEY
transaction_id UUID FOREIGN KEY
from_status TEXT NULLABLE
to_status TEXT
actor_id UUID NULLABLE (who made the change)
notes TEXT NULLABLE
created_at TIMESTAMP
```

### audit_logs
```sql
id UUID PRIMARY KEY
user_id UUID NULLABLE (who performed action)
actor_id UUID NULLABLE (alias for user_id)
target_user_id UUID NULLABLE (who was affected)
action TEXT (e.g., 'profit_balance_updated')
entity TEXT NULLABLE (e.g., 'account')
entity_id TEXT NULLABLE (e.g., account UUID)
details JSONB (structured data about the change)
result TEXT DEFAULT 'success' ('success' | 'failure')
created_at TIMESTAMP
```

## API Integration Points

### Supabase Client API
- `supabase.auth.signUp()` - Create account
- `supabase.auth.signInWithPassword()` - Sign in
- `supabase.auth.getSession()` - Get current session
- `supabase.auth.signOut()` - Sign out
- `supabase.from('table').select()` - Query data
- `supabase.from('table').insert()` - Create record
- `supabase.from('table').update()` - Modify record

### Real-time Features (Not Yet Implemented)
```typescript
// Listen for account balance changes
supabase
  .channel('accounts')
  .on('postgres_changes', 
    { event: 'UPDATE', schema: 'public', table: 'accounts' },
    payload => console.log('Balance updated:', payload)
  )
  .subscribe()
```

## Design System

### Color Palette
- **Dark Base**: `#0a0a0a` (gray-950)
- **Dark Secondary**: `#1a1a1a` (gray-900)
- **Dark Tertiary**: `#2a2a2a` (gray-800)
- **Accent Primary**: `#10b981` (emerald-500)
- **Accent Secondary**: `#f59e0b` (amber-500)

### Typography
- **Headings**: Playfair Display (serif)
- **Body**: Inter (sans-serif)
- **Numbers**: Monospace fonts (for currency)

### Components
- **Cards**: Glassmorphism effect with backdrop blur
- **Buttons**: Three variants (primary/secondary/ghost)
- **Forms**: Clean, focused inputs with emerald accent
- **Tables**: Striped rows, monospace currency

### Responsive Breakpoints (Tailwind)
- `sm`: 640px
- `md`: 768px
- `lg`: 1024px
- `xl`: 1280px

## Performance Optimizations

1. **Next.js Features**
   - Server-side rendering for landing page
   - Client-side hydration for auth flows
   - Image optimization (unoptimized for now)
   - CSS purging via Tailwind

2. **Vercel Features**
   - Edge caching for static assets
   - Automatic GZIP compression
   - CDN distribution globally
   - Automatic scaling

3. **Supabase Features**
   - Connection pooling
   - Query result caching
   - JWT-based stateless auth
   - RLS policies prevent over-fetching

## Security Considerations

### Frontend Security
- ✅ Sensitive keys NOT in code (environment variables)
- ✅ Anon key safe to expose (can't do privileged operations)
- ✅ Service role key NEVER exposed to frontend
- ✅ HTTPS enforced on Vercel
- ⏳ TODO: CSRF protection
- ⏳ TODO: Rate limiting

### Backend Security
- ✅ Row Level Security policies
- ✅ Email verification status
- ✅ Account suspension capability
- ✅ Audit logging of admin actions
- ✅ Immutable transaction history
- ⏳ TODO: 2FA/MFA
- ⏳ TODO: IP whitelisting
- ⏳ TODO: Transaction signing

### Data Security
- ✅ Passwords hashed by Supabase (bcrypt)
- ✅ Encrypted connections (HTTPS/TLS)
- ✅ Database backups (Supabase managed)
- ✅ PCI-DSS ready infrastructure
- ⏳ TODO: Encryption at rest
- ⏳ TODO: Data backup strategy

## Monitoring & Logging

### What Gets Logged
1. **Authentication Events**
   - Sign ups
   - Sign ins
   - Sign outs
   - Failed login attempts

2. **Admin Actions**
   - Profit balance updates
   - Account status changes
   - Verification status changes

3. **Transactions**
   - All transaction status changes
   - Fee adjustments
   - Recipient updates

### Viewing Logs
- **Browser Console**: Real-time app errors
- **Vercel Dashboard**: Build logs and runtime errors
- **Supabase Dashboard**: Database queries and auth events
- **Database**: Query `audit_logs` table directly

## Future Enhancements

### Phase 2: Transaction Features
- Deposit processing modal with payment methods
- Withdrawal requests with admin approval
- P2P transfers between clients
- Real-time transaction status updates
- Email notifications

### Phase 3: Compliance & Verification
- KYC/AML user verification
- Document upload and storage
- Two-factor authentication (2FA)
- IP whitelisting
- Trading restrictions

### Phase 4: Advanced Analytics
- Portfolio performance charts
- Transaction history analytics
- Tax reporting exports
- Risk assessment dashboards
- Anomaly detection

### Phase 5: Mobile App
- React Native app
- Biometric authentication
- Push notifications
- Offline mode support

## Deployment Checklist

- ✅ Supabase project created and configured
- ✅ Database tables and schema ready
- ✅ Next.js app built and tested
- ⏳ GitHub repository created
- ⏳ Vercel project linked
- ⏳ Environment variables configured
- ⏳ Initial deployment complete
- ⏳ Testing across user flows completed
- ⏳ SSL certificate verified (automatic on Vercel)
- ⏳ Custom domain setup (optional)

## Getting Help

### Documentation
- Next.js: https://nextjs.org/docs
- Supabase: https://supabase.com/docs
- Tailwind: https://tailwindcss.com/docs
- Vercel: https://vercel.com/docs

### Community
- Supabase Discord: https://discord.supabase.com
- Next.js Discord: https://discord.gg/nextjs
- Stack Overflow (tag your questions)
