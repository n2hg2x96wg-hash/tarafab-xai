# Testing Checklist - Before Going Live

After deployment, run through these tests to ensure everything works correctly.

## 1. Landing Page ✅

Visit your deployed URL (e.g., `https://tarafab-xai-xxxxx.vercel.app/`)

- [ ] Page loads without errors
- [ ] BTC/USD ticker visible in header
- [ ] Price updates every ~2 seconds
- [ ] Sparkline chart animates smoothly
- [ ] Hero section text readable
- [ ] Feature cards visible
- [ ] "Sign In" button works
- [ ] "Get Started" button works
- [ ] Footer visible with links
- [ ] Page is responsive on mobile

## 2. Sign Up Flow 📝

Click "Get Started" → Fill form → Submit

- [ ] Can enter full name
- [ ] Can enter email
- [ ] Can enter password (8+ chars)
- [ ] Can confirm password
- [ ] Submit button works
- [ ] Error if passwords don't match
- [ ] Error if password too short
- [ ] Redirects to /dashboard after signup
- [ ] New account appears in Supabase (check database)
- [ ] Account starts with $0 balance
- [ ] Profile created with role = 'customer'

### Verify in Supabase Dashboard:
1. Go to https://app.supabase.com → Your Project
2. Check **Authentication**:
   - New user email is listed
3. Check **profiles table**:
   - New row with matching email
   - `role` = 'customer'
4. Check **accounts table**:
   - New row with `user_id` matching
   - `account_balance` = 0
   - `available_balance` = 0

## 3. Sign In with Demo Account 🔐

Go to `/sign-in` → Enter demo credentials

- [ ] Email field accepts input
- [ ] Password field accepts input
- [ ] "Remember me" checkbox works
- [ ] "Forgot password" link clickable (doesn't need to work yet)
- [ ] Submit button works with valid credentials
- [ ] Error message if wrong password
- [ ] Error message if email not found
- [ ] Redirects to /dashboard after successful login
- [ ] Session persists after page refresh
- [ ] Can logout and sign back in

**Demo Credentials:**
- Email: `alex@example.com`
- Password: `client123`

## 4. Client Dashboard 📊

After signing in, verify dashboard shows correct data:

- [ ] Page title shows account name
- [ ] Email displayed correctly
- [ ] Account Balance card shows (should be $0 for new account)
- [ ] Profit Balance card shows (should be $0 for new account)
- [ ] Available Balance shows
- [ ] Invested Balance shows
- [ ] Action buttons visible (Deposit, Withdraw, Transfer, History)
- [ ] Recent Transactions section visible
- [ ] "Sign Out" button works
- [ ] After sign out, redirected to landing page
- [ ] Can't access dashboard without logging in

### Data Verification:
1. Create new account via sign up
2. Check dashboard shows $0 / $0
3. Go to Supabase → accounts table
4. Verify row exists with correct user_id and zero balances

## 5. Admin Access Flow 👨‍💼

Go to `/staff-login` → Enter admin password → Access admin panel

- [ ] Staff login page loads
- [ ] Password field accepts input
- [ ] Error message if wrong password
- [ ] Admin panel accessible with correct password
- [ ] Admin panel shows table of all clients
- [ ] Each client row shows: Name, Email, Account Balance, Profit Balance
- [ ] "Edit" button appears on each row

### Admin Edit Profit Balance:
1. Click "Edit" on any client
2. Input field appears
3. Enter new number
4. Click "Save"
5. Loading state appears while saving
6. Value updates in table
7. Verify in Supabase → accounts table → `available_balance` changed

**Admin Password:**
- Password: `admin123`

## 6. Role-Based Access Control 🔒

Test that users are routed correctly:

### Customer Should Not Access `/admin`:
1. Sign in as customer
2. Manually go to `/admin`
3. Should redirect to `/dashboard`

### Admin Sees Dashboard:
1. Sign in as admin account
2. Automatically redirected to `/admin` (not `/dashboard`)
3. Can access `/admin` directly

### Staff Login Requires Admin Role:
1. Sign in as regular customer
2. Go to `/staff-login`
3. Enter correct password
4. Should error: "Only admin accounts can access"

## 7. Data Persistence ✅

Test that data saves to database:

1. Sign up new account with unique email
2. Go to Supabase Dashboard → Authentication
3. Verify new user exists
4. Go to Supabase Dashboard → profiles table
5. Verify matching profile row
6. Go to Supabase Dashboard → accounts table
7. Verify matching account with zero balances
8. Wait 5 minutes, refresh browser
9. Sign in again - all data should be intact

## 8. Error Handling 🚨

Test error scenarios:

- [ ] Invalid email format rejected on signup
- [ ] Blank fields rejected with error message
- [ ] Network error shows graceful message
- [ ] Database connection error shows error
- [ ] Expired session redirects to login
- [ ] Invalid JWT token handled gracefully

## 9. Responsive Design 📱

Test on different screen sizes:

### Mobile (iPhone/Android):
- [ ] Landing page layout adapts
- [ ] Text is readable
- [ ] Buttons are touch-friendly
- [ ] Tables scroll horizontally on mobile
- [ ] Forms stack vertically
- [ ] Header adapts to small screens

### Tablet:
- [ ] Layout uses mid-sized columns
- [ ] Dashboard cards stack properly
- [ ] All elements visible

### Desktop (1920px+):
- [ ] Full layout utilizes width
- [ ] Tables displayed properly
- [ ] Cards in multi-column grid

Test using:
- Browser DevTools → Device Toolbar
- Real devices if available

## 10. Performance Checks ⚡

- [ ] Page loads in under 3 seconds
- [ ] No console errors (check browser console)
- [ ] No network request failures
- [ ] BTC ticker continues updating
- [ ] Dashboard loads data smoothly
- [ ] Admin table doesn't lag with many records

### Check Performance:
1. Open DevTools → Network tab
2. Reload page
3. Look for failed requests (red)
4. Check response times (should be <500ms per request)

## 11. Browser Compatibility 🌐

Test in different browsers:

- [ ] Chrome/Chromium (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)
- [ ] Edge (latest)
- [ ] Mobile Chrome
- [ ] Mobile Safari

## 12. Supabase Configuration Verification ✔️

Double-check everything is configured:

1. **Authentication Settings**
   - Go to Supabase → Authentication → Settings
   - [ ] Email provider enabled
   - [ ] Password authentication enabled
   - [ ] Auto-confirm emails OFF (if using email verification)

2. **Database Tables**
   - [ ] `auth.users` exists (Supabase managed)
   - [ ] `profiles` table exists with correct columns
   - [ ] `accounts` table exists with correct columns
   - [ ] `transactions` table exists
   - [ ] `audit_logs` table exists

3. **Row Level Security (RLS)**
   - Go to Supabase → Database → RLS
   - [ ] RLS enabled on `profiles` table
   - [ ] RLS enabled on `accounts` table
   - [ ] RLS enabled on `transactions` table

## 13. Environment Variables Verification 🔑

- [ ] `NEXT_PUBLIC_SUPABASE_URL` is set in Vercel
- [ ] `NEXT_PUBLIC_SUPABASE_ANON_KEY` is set in Vercel
- [ ] `SUPABASE_SERVICE_ROLE_KEY` is set in Vercel
- [ ] App still works after environment change
- [ ] No error messages about missing env vars

Check in Vercel:
1. Go to https://vercel.com/dashboard
2. Select your project
3. Go to Settings → Environment Variables
4. Verify all three variables are there

## 14. Security Spot Checks 🔐

- [ ] `.env.local` file is NOT in GitHub (check .gitignore)
- [ ] No passwords hardcoded in frontend
- [ ] No Supabase keys logged to console in production
- [ ] HTTPS used (automatic on Vercel)
- [ ] Form passwords masked in input fields
- [ ] Session tokens secure (HttpOnly cookies)

## 15. Production Ready Checklist ✅

Before sharing with clients:

- [ ] All tests above passed
- [ ] No console errors in production
- [ ] No Vercel warnings in build
- [ ] Custom domain configured (optional)
- [ ] Email notifications tested (once implemented)
- [ ] Backup strategy in place (Supabase backups)
- [ ] Monitoring set up (Vercel analytics)
- [ ] Error logging configured (optional: Sentry, LogRocket)
- [ ] Terms of Service visible
- [ ] Privacy Policy visible
- [ ] Contact/Support info added

## Issues Found?

If something fails:

1. **Check Vercel Logs**
   - Vercel Dashboard → Your Project → Deployments
   - Click latest deployment
   - Review build and runtime logs

2. **Check Browser Console**
   - Right-click → Inspect → Console tab
   - Look for JavaScript errors

3. **Check Supabase**
   - Check project is active and healthy
   - Verify tables exist with data
   - Check RLS policies aren't blocking access

4. **Check Network**
   - DevTools → Network tab
   - Look for failed requests (red)
   - Check response codes (should be 200, 201, etc.)

5. **Reset Everything**
   - Delete `.next` folder locally
   - Run `npm install` again
   - Run `npm run build`
   - Deploy again

## Success! 🎉

If all checks pass, your app is ready for:
- ✅ Testing with stakeholders
- ✅ Sharing with early beta users
- ✅ Feature development
- ✅ Production deployment

Next steps:
1. Document any issues found
2. Plan Phase 2 features (deposits, withdrawals, transfers)
3. Set up monitoring and alerting
4. Create user onboarding flow
5. Plan security audit
