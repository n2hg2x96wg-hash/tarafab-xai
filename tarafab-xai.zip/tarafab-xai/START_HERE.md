# 🚀 START HERE - Tarafab.XAi Setup Guide

Welcome! Your complete investment platform is ready. Follow this guide step-by-step.

**Estimated time: 30-45 minutes**

## What You Have

✅ **Complete Next.js frontend** - All pages, components, and styling
✅ **Connected to Supabase** - Real database, auth, user management
✅ **Ready for Vercel** - Automatic deployment on every code change
✅ **All features implemented** - Landing, auth, dashboard, admin panel

## What You Need to Do

1. Get Supabase credentials (2 min)
2. Create GitHub repository (5-10 min)
3. Deploy to Vercel (5-10 min)
4. Test everything (10 min)
5. Go live! 🎉

---

## ⚙️ Step 1: Get Supabase Credentials

Your Supabase project is already set up. You just need the API keys.

### Get Your Keys

1. Open https://app.supabase.com
2. Click your **Tarafab.XAi** project
3. Go to **Settings** (left sidebar) → **API**
4. You'll see two key sections. Save these values somewhere safe:

```
NEXT_PUBLIC_SUPABASE_URL
(Find "Project URL" - should be https://jdskpqjwmaeurxspipyv.supabase.co)

NEXT_PUBLIC_SUPABASE_ANON_KEY
(Find the "anon" key under "Project API keys")

SUPABASE_SERVICE_ROLE_KEY
(Find at the bottom - marked with "SECRET")
```

💡 **Tip**: Use a notes app to paste these temporarily. You'll need them in 5 minutes.

---

## 📝 Step 2: Create GitHub Repository

You have two options:

### Option A: Using Browser Only (Easiest for Phone)

1. Go to https://github.com/new
2. Fill in:
   - Repository name: `tarafab-xai`
   - Description: `Investment management platform`
   - Select: **Private** (recommended)
3. Click **Create repository**
4. You'll see instructions. Instead:
   - Click **Add file** → **Upload files**
   - Upload ALL files from this folder
5. After upload, click **Commit changes**

### Option B: Using Git (More Powerful)

If you have Git installed on your computer:

```bash
# In the tarafab-xai folder
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/tarafab-xai.git
git push -u origin main
```

Then go to GitHub and link this repo to Vercel (next step).

---

## 🌐 Step 3: Deploy to Vercel

### Create Vercel Account

1. Go to https://vercel.com
2. Click **Sign Up**
3. Sign in with GitHub account

### Deploy Your App

1. After signing in, click **+ New Project**
2. Click **Import Git Repository**
3. Find your `tarafab-xai` repository and click it
4. Click **Import**

### Configure Environment Variables ⚠️ CRITICAL

Before clicking "Deploy", you MUST add environment variables:

1. Look for **Environment Variables** section
2. Add three variables:

| Name | Value |
|------|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://jdskpqjwmaeurxspipyv.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | *Paste your Anon Key from Step 1* |
| `SUPABASE_SERVICE_ROLE_KEY` | *Paste your Service Role Key from Step 1* |

3. Click **Deploy**

### Wait for Deployment

Vercel will build your app. This takes 2-5 minutes.

When done, you'll see a success message with your live URL:
```
https://tarafab-xai-xxxxx.vercel.app
```

✅ **Save this URL** - this is your app!

---

## ✅ Step 4: Test Everything

### Test These Flows

1. **Landing Page**
   - Visit your Vercel URL
   - See BTC ticker updating
   - Click "Get Started" and "Sign In" buttons

2. **Sign Up**
   - Fill out the form
   - Create account with your email
   - Should show dashboard with $0 balance

3. **Sign In (Demo)**
   - Go to `/sign-in`
   - Email: `alex@example.com`
   - Password: `client123`
   - Should see dashboard with account info

4. **Admin Panel**
   - Go to `/staff-login`
   - Enter password: `admin123`
   - Should see table of all clients
   - Click "Edit" on profit balance
   - Change a number and save
   - Verify it updates

### If Something's Wrong

See **Troubleshooting** section below.

---

## 📚 Documentation

- **README.md** - Feature list and architecture
- **DEPLOYMENT_GUIDE.md** - Detailed step-by-step guide
- **ARCHITECTURE.md** - Technical deep dive
- **TESTING_CHECKLIST.md** - Full test plan
- **DEPLOYMENT_GUIDE.md** - Environment variables

---

## 🎯 Your Deployed App Includes

### Public Pages
- ✅ `/` - Landing page with BTC ticker
- ✅ `/sign-in` - Customer login
- ✅ `/sign-up` - Create new account

### Authenticated Pages
- ✅ `/dashboard` - Customer account view
- ✅ `/admin` - Admin panel for staff
- ✅ `/staff-login` - Password gate for admin access

### Built-In Features
- ✅ Real Supabase authentication
- ✅ Account creation with zero balances
- ✅ Profile management (name, email, role)
- ✅ Admin profit balance editing
- ✅ Transaction history display
- ✅ Role-based access control
- ✅ Session persistence
- ✅ Secure logout
- ✅ Live BTC price ticker
- ✅ Animated landing page
- ✅ Responsive mobile design
- ✅ Dark mode fintech aesthetic

---

## 🔐 Demo Credentials

### For Testing:

**Customer Account:**
- Email: `alex@example.com`
- Password: `client123`

**Admin Access:**
- Staff Password: `admin123`

Create your own real accounts for production!

---

## 🚨 Troubleshooting

### App is blank/white screen
- Check Vercel logs: https://vercel.com/dashboard → Your Project → Deployments
- Look for build errors
- Most common: Missing environment variables

### "Supabase connection failed"
- Verify the three environment variables in Vercel are correct
- Check for extra spaces or typos
- Make sure keys are from the right project (jdskpqjwmaeurxspipyv)

### Sign up/Sign in doesn't work
- Check browser console for errors (F12)
- Verify Supabase project is active
- Make sure email/password format is correct

### Admin panel blank
- Make sure you're signed in as an admin user
- Demo account is customer, not admin
- Create a new admin account first (see DATABASE SETUP below)

---

## 🗄️ Database Setup (First Time)

Your database tables are already created, but they're empty. 

### Create an Admin Account

You have two options:

**Option 1: Via Supabase Dashboard** (Recommended)
1. Go to https://app.supabase.com → Your Project
2. Click **Authentication**
3. Click **Users** tab
4. Click **Add user** → **Invite with email** (or create manually)
5. Set email: `admin@example.com`
6. Set password: `admin123` (change this in production!)
7. Go to **profiles** table
8. Find the row for this user
9. Change `role` from 'customer' to 'admin'

**Option 2: Manually Insert**
1. Go to Supabase → Your Project
2. Click **SQL Editor**
3. Paste this query and run it:

```sql
-- Create admin user (Supabase Auth)
-- First, go to Authentication tab and create a user with email admin@example.com

-- Then in profiles table, add:
INSERT INTO profiles (id, full_name, role, account_status, verification_status)
VALUES (
  'USER_UUID_HERE',  -- Replace with the user's UUID from auth.users
  'Admin User',
  'admin',
  'active',
  'verified'
);

-- And in accounts table:
INSERT INTO accounts (user_id, account_balance, available_balance, invested_balance, pending_balance)
VALUES (
  'USER_UUID_HERE',  -- Same UUID
  0,
  0,
  0,
  0
);
```

---

## 📋 Next Steps After Going Live

1. **Customize** - Update colors, text, branding
2. **Add Deposit/Withdraw** - Implement payment processing
3. **Email Notifications** - Send updates to users
4. **2FA Security** - Add two-factor authentication
5. **KYC Verification** - User identity verification
6. **Custom Domain** - `yourdomain.com` instead of Vercel URL

See **ARCHITECTURE.md** for feature roadmap.

---

## ⚡ Making Updates

Once deployed, updating is simple:

1. Make changes in your GitHub repo
2. Commit and push
3. Vercel automatically rebuilds and deploys
4. Changes live in 1-2 minutes

No manual deployment needed!

---

## 💬 Getting Help

### Common Questions

**Q: Can I use this on my phone?**
A: Yes! All web pages work on mobile. For development, use GitHub's web editor.

**Q: How do I add more features?**
A: Edit files in GitHub, commit, and Vercel deploys. See code comments for guidance.

**Q: Is this production-ready?**
A: It's feature-complete but review TESTING_CHECKLIST.md before launching to real users.

**Q: How do I add my own domain?**
A: In Vercel dashboard, go to Settings → Domains. Follow their guide.

**Q: How do I enable email verification?**
A: Supabase Settings → Auth → Email → Configure SMTP. See Supabase docs.

### Documentation Links

- Next.js: https://nextjs.org/docs
- Supabase: https://supabase.com/docs
- Vercel: https://vercel.com/docs
- Tailwind: https://tailwindcss.com/docs

### Need Code Help?

1. Check code comments (they explain everything)
2. Review the relevant documentation link above
3. Search Stack Overflow for similar issues

---

## ✅ Verification Checklist

Before celebrating, verify:

- [ ] Vercel deployment succeeded (no errors)
- [ ] Landing page loads
- [ ] BTC ticker updates live
- [ ] Can sign up with new email
- [ ] Can sign in with `alex@example.com`
- [ ] Dashboard shows account balances
- [ ] Can access admin panel with password
- [ ] Admin can edit profit balance
- [ ] Changes save to database

If all ✅, you're done! 🎉

---

## 📞 Support

If you get stuck:

1. Check the relevant documentation file (README.md, DEPLOYMENT_GUIDE.md, etc.)
2. Review browser console for error messages (F12)
3. Check Vercel logs for build errors
4. Verify all environment variables are set correctly

**You've got this!** 💪

---

## 🎉 Congratulations!

You now have:
- ✅ A fully-functional investment platform
- ✅ Real authentication via Supabase
- ✅ A professional UI/UX
- ✅ Automatic deployment pipeline
- ✅ A foundation for growth

**Start here, then explore the other documentation files for deeper details.**

**Next deployment is one Git push away!** 🚀
