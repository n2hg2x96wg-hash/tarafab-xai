# Tarafab.XAi - Deployment Checklist

## Phase 1: Prepare Your Supabase Credentials ✓

Your Supabase project is ready: `jdskpqjwmaeurxspipyv`

### Step 1: Get Your Keys
1. Visit https://app.supabase.com
2. Click your "Tarafab.XAi" project
3. Go to **Settings → API** (left sidebar)
4. Save these three values (you'll need them soon):

```
Project URL:
https://jdskpqjwmaeurxspipyv.supabase.co

Anon Key (Public):
[Look for "anon" key in the "Project API keys" section]

Service Role Key (Secret - keep safe!):
[Look for "service_role" key - at the bottom, marked as "SECRET"]
```

## Phase 2: Create GitHub Repository

### If you can access a computer:
1. Go to https://github.com/new
2. Create repository: `tarafab-xai`
3. Choose "Private"
4. Click "Create repository"
5. You'll see code to copy. Instead:
   - Click "Add file" → "Upload files"
   - Upload all files from this project folder
6. Once uploaded, files are committed

### If you only have a phone:
1. Install "GitHub Desktop" app (iOS/Android has limited support)
2. Alternative: Use "Working Copy" app on iOS
3. Ask for help from someone who can use a computer to set this up

## Phase 3: Connect to Vercel

1. Go to https://vercel.com
2. Sign in (create account if needed - free tier works)
3. Click "+ New Project"
4. Select "Import Git Repository"
5. Find and click your `tarafab-xai` repository
6. **CRITICAL**: Add Environment Variables before deploying:
   - Click "Environment Variables"
   - Add three variables:
     * Name: `NEXT_PUBLIC_SUPABASE_URL`
       Value: `https://jdskpqjwmaeurxspipyv.supabase.co`
     * Name: `NEXT_PUBLIC_SUPABASE_ANON_KEY`
       Value: [Paste your Anon Key from step 1]
     * Name: `SUPABASE_SERVICE_ROLE_KEY`
       Value: [Paste your Service Role Key from step 1]
7. Click "Deploy"

⏳ Wait 2-3 minutes for deployment to complete.

## Phase 4: Test Your App

Once deployed, Vercel will give you a URL like:
```
https://tarafab-xai-xxxxx.vercel.app
```

### Test the user flows:

1. **Landing Page** (public)
   - Visit home page
   - See BTC ticker updating in header
   - See feature cards

2. **Sign Up** (create new account)
   - Click "Get Started"
   - Fill form: name, email, password (8+ chars)
   - Should redirect to dashboard with $0 balance

3. **Sign In** (use demo account)
   - Click "Sign In"
   - Email: `alex@example.com`
   - Password: `client123`
   - Should show account with balances

4. **Admin Panel** (staff only)
   - Go to URL: `/staff-login`
   - Enter password: `admin123`
   - Should show list of all clients
   - Click "Edit" on profit balance
   - Change amount and save
   - Check that client's account updated

## Phase 5: Ongoing Maintenance

### To make updates:
1. Edit files in your GitHub repo (web editor works fine)
2. Commit changes
3. Vercel automatically redeploys (watch status at https://vercel.com/dashboard)

### To add features:
1. Edit relevant file(s)
2. Test locally if possible: `npm run dev`
3. Git commit and push
4. Vercel handles deployment

## Troubleshooting

### Blank page after deployment?
- Check Vercel build logs: https://vercel.com/dashboard → Your Project → Deployments
- Look for error messages in the logs
- Most common: Missing environment variables

### "Supabase connection failed" in browser console?
- Verify you copied the exact URL and keys
- Check for extra spaces or typos in env variables
- Make sure keys are from the right Supabase project

### Sign in doesn't work?
- Verify user exists in Supabase → Authentication
- Check password is correct
- Review browser console for specific error

### Admin panel shows blank table?
- Make sure you created at least one customer account first
- Admin panel only shows customer accounts (role = 'customer')

## Important URLs

| Page | URL | Access |
|------|-----|--------|
| Landing | `/` | Public |
| Sign In | `/sign-in` | Public |
| Sign Up | `/sign-up` | Public |
| Dashboard | `/dashboard` | Logged-in customers |
| Admin | `/admin` | Logged-in admins only |
| Staff Login | `/staff-login` | Logged-in users (password gate) |

## Demo Credentials

Keep these safe - they're for testing:

**Customer Account:**
- Email: `alex@example.com`
- Password: `client123`

**Admin Access:**
- Staff Password: `admin123`

Create real accounts for production use.

## Security Notes

🔒 **Never:**
- Commit `.env.local` file
- Share service role key publicly
- Use demo passwords in production
- Store passwords in code

✅ **Always:**
- Use strong, unique passwords
- Keep service role key secret
- Enable email verification
- Set up 2FA for admin accounts
- Review audit logs regularly

## Quick Commands (if developing locally)

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Run linter
npm run lint
```

## File Structure Quick Reference

```
tarafab-xai/
├── app/
│   ├── page.tsx              ← Landing page
│   ├── sign-in/page.tsx      ← Sign in
│   ├── sign-up/page.tsx      ← Sign up
│   ├── dashboard/page.tsx    ← Client dashboard
│   ├── admin/page.tsx        ← Admin panel
│   ├── staff-login/page.tsx  ← Staff gate
│   ├── layout.tsx            ← App shell
│   └── globals.css           ← Global styles
├── lib/
│   └── supabase/
│       ├── client.ts         ← Browser client
│       └── server.ts         ← Server client
├── package.json              ← Dependencies
├── tailwind.config.js        ← Tailwind config
├── tsconfig.json             ← TypeScript config
└── .env.local.example        ← Env template (rename to .env.local)
```

## When You're Ready

After deployment completes:
1. Open your Vercel URL
2. Test sign up/sign in flows
3. Access admin at `/staff-login`
4. Verify database changes are saved to Supabase

Then you're live! 🚀

---

Questions? Check README.md for more details or review the code comments in each file.
