# Tarafab.XAi - Investment Platform

A modern, fully-featured investment management platform built with Next.js, Supabase, and Tailwind CSS.

## Features

### Public Landing Page
- Live BTC/USD ticker with real-time price updates
- Animated market chart with live data visualization
- Feature cards with fade-in animations
- Responsive design optimized for all devices

### Authentication System
- Supabase Auth integration with email/password
- Sign up with automatic profile and account creation
- Sign in with session persistence
- Role-based access control (customer vs admin)

### Client Dashboard
- Real-time account balance display
- Profit balance management
- Available and invested balance breakdown
- Transaction history with status tracking
- Action buttons for Deposit, Withdraw, Transfer, History

### Admin Panel
- View all client accounts
- Edit profit balance per client (inline editing)
- Account and transaction audit trail
- Staff-only access with password gate

## Tech Stack

- **Frontend**: Next.js 14+ with TypeScript
- **Styling**: Tailwind CSS with custom design system
- **Backend**: Supabase (PostgreSQL + Auth)
- **Deployment**: Vercel

## Project Structure

```
tarafab-xai/
├── app/
│   ├── layout.tsx              # Root layout
│   ├── globals.css             # Global styles
│   ├── page.tsx                # Landing page
│   ├── sign-in/page.tsx        # Sign in page
│   ├── sign-up/page.tsx        # Sign up page
│   ├── dashboard/page.tsx      # Client dashboard
│   ├── admin/page.tsx          # Admin panel
│   └── staff-login/page.tsx    # Staff access gate
├── lib/
│   └── supabase/
│       ├── client.ts           # Browser client
│       └── server.ts           # Server client
├── package.json
├── tsconfig.json
├── tailwind.config.js
├── postcss.config.js
└── next.config.js
```

## Setup Instructions

### 1. Prerequisites

You'll need:
- A GitHub account
- A Vercel account (free tier works)
- Supabase project already set up (you already have: `jdskpqjwmaeurxspipyv`)

### 2. Get Supabase Credentials

1. Go to https://app.supabase.com
2. Open your Tarafab.XAi project (jdskpqjwmaeurxspipyv)
3. Click "Settings" → "API"
4. Copy:
   - **Project URL** (looks like: `https://jdskpqjwmaeurxspipyv.supabase.co`)
   - **Anon Key** (public key)
   - **Service Role Key** (secret key - keep safe!)

### 3. Create GitHub Repository (Phone-Friendly)

**Option A: Using GitHub Web (No Terminal Needed)**

1. Go to https://github.com/new
2. Create a new repository named `tarafab-xai`
3. Choose "Private" (recommended)
4. Click "Create repository"
5. You'll see the quick setup screen. Copy all the files from this project folder
6. Use GitHub's web editor:
   - Click "Add file" → "Create new file"
   - Name: `package.json` and paste the content
   - Repeat for all other files
7. After all files are uploaded, click "Commit changes"

**Option B: Using GitHub Desktop App (Easier for Phone)**

1. Download GitHub Desktop (https://desktop.github.com)
2. Open Terminal/CMD and navigate to the `tarafab-xai` folder
3. Run: `git init`
4. Run: `git add .`
5. Run: `git commit -m "Initial commit"`
6. In GitHub Desktop, File → Add Local Repository → select the folder
7. Click "Publish repository"

### 4. Connect to Vercel

1. Go to https://vercel.com
2. Click "New Project"
3. Import your GitHub repository (`tarafab-xai`)
4. In **Environment Variables**, add:
   - `NEXT_PUBLIC_SUPABASE_URL`: Your Supabase project URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Your Supabase anon key
   - `SUPABASE_SERVICE_ROLE_KEY`: Your service role key
5. Click "Deploy"

Vercel will automatically deploy whenever you push to GitHub.

## Environment Variables

Create a `.env.local` file in the project root:

```env
NEXT_PUBLIC_SUPABASE_URL=https://jdskpqjwmaeurxspipyv.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
```

**Never commit this file!** It's already in `.gitignore`.

## Running Locally (Development)

```bash
npm install
npm run dev
```

Visit http://localhost:3000

## Demo Credentials

### Client Account
- Email: `alex@example.com`
- Password: `client123`

### Admin Access
- Staff Password: `admin123`
- Access at: `/staff-login`

## Database Schema

The app uses these Supabase tables:

### profiles
- `id` (uuid) - Foreign key to auth.users
- `full_name` (text)
- `role` (text) - 'customer' or 'admin'
- `email_verified_at` (timestamp)
- `account_status` (text) - 'active' or 'suspended'
- `verification_status` (text)
- `created_at`, `updated_at` (timestamp)

### accounts
- `id` (uuid) - Primary key
- `user_id` (uuid) - Foreign key to auth.users
- `account_balance` (numeric) - Total account value
- `available_balance` (numeric) - Profit balance (editable by admin)
- `invested_balance` (numeric) - Currently deployed funds
- `pending_balance` (numeric) - Awaiting confirmation
- `created_at`, `updated_at` (timestamp)

### transactions
- `id` (uuid)
- `user_id` (uuid)
- `type` (text) - deposit, withdrawal, transfer_out, transfer_in, investment, fee, return, adjustment
- `amount` (numeric)
- `status` (text) - pending, processing, completed, rejected, etc.
- `created_at`, `updated_at` (timestamp)
- Additional fields: `method`, `fee`, `asset`, `address`, `network`, `recipient_id`, `tx_hash`

### audit_logs
- Comprehensive logging of all admin actions
- Fields: `user_id`, `action`, `entity`, `entity_id`, `details`, `result`

## User Flows

### New Customer Sign Up
1. Land on `/` (home page)
2. Click "Get Started"
3. Fill out form at `/sign-up`
4. Account created with $0 balance
5. Redirected to `/dashboard`

### Customer Sign In
1. Click "Sign In" on landing page
2. Email + password at `/sign-in`
3. Routed to `/dashboard` (or `/admin` if admin role)

### Admin Profit Balance Edit
1. Customer opens account → admin edits available_balance
2. Admin goes to `/staff-login`
3. Enters staff password
4. Redirected to `/admin`
5. Finds client in table
6. Clicks "Edit" on Profit Balance
7. Updates value and clicks "Save"
8. Change is immediately reflected in client's account

## Deployment

Every push to your GitHub repository automatically triggers a Vercel deployment.

To update:
1. Make code changes in your repo
2. Git commit and push
3. Vercel rebuilds and deploys automatically
4. Check deployment status at https://vercel.com/dashboard

## Next Steps

### To Add Features:
1. Deposit Modal - process deposits via crypto or bank transfer
2. Withdraw Modal - process withdrawal requests
3. Transfer Modal - p2p transfers between clients
4. Transaction History Page - detailed transaction view
5. Bitcoin Deposit Address - unique per client with webhook tracking
6. Real OTP Auth - 2FA for additional security
7. Email Notifications - alerts for transactions
8. KYC/AML Verification - regulatory compliance

### Design Polish:
- Add loading skeletons
- Implement error boundaries
- Add toast notifications
- Mobile-optimize modals

## Support

For issues with:
- **Supabase**: Visit https://supabase.com/docs
- **Vercel**: Visit https://vercel.com/docs
- **Next.js**: Visit https://nextjs.org/docs

## License

Private - Tarafab.XAi
